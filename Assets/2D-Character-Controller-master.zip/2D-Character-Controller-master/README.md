# 2D Character Controller
Here is a free to use Character Controller for 2D platformer games in Unity.

![Image of Sunny Land from the Asset Store](http://i.imgur.com/ni1t2Wq.jpg)

Currently the Controller features:

- Smooth movement
- Jumping
- Crouching
- Events for setting up animation
- 2D Physics

To learn how to use it check out our video on 2D Movement which can be found on our [YouTube Channel](http://youtube.com/brackeys).

The script is based on the one provided by Unity as part of their Standard Assets.